---
title: "About Me"
description: "All About Me"
date: "2015-08-18"
type: "about"
layout: "single"
categories:
    - "bio"
    - "about"
    - "meta"
tags:
    - "bio"
blurb: "Just a city boy, born and raised in South Detroit"
recentposts: 5
recentprojects: 5
photo: "/images/avatar.png"
cardheaderimage: "/images/default.jpg" #optional: default solid color if unset
cardbackground: "#263238" #optional: card background color; only shows when no image specified
---

90's slow-carb Schlitz Shoreditch mixtape typewriter, wayfarers Austin keffiyeh 
Helvetica artisan flexitarian. Health goth vinyl scenester pickled kitsch. 
Organic slow-carb stumptown freegan, PBR ugh chia Intelligentsia pork belly 
locavore retro kale chips. Tofu put a bird on it squid tattooed beard master 
cleanse, mumblecore keytar mustache blog direct trade PBR&B quinoa.

#### Education

- 2015 - Master of Arts in Wine Tasting, University of British Columbia

- 2013 - Bachelor of Arts , University of British Columbia
 

#### Publications

- Painting with condiments (2015) 

#### Places I've worked

I don't work :(
