---
title: "A Cool Website" 
date: "2015-09-27"
description: "This was a cool website I made"
#cardimage: "/images/default.jpg"
#headerimage: "/images/default.jpg"
cardbackground: "#263238"
web: "http://github.com/sampleproject"
repo: "http://github.com/sampleproject"
"author":
  description: "Writer of stuff"
  email: "jeremy@example.com"
  github: "https://github.com/example/"
  name: "First Last"
  twitter: "http://twitter.com/Jeremy_Atkinson"
  website: "http://example.com/bio/"
categories:
  - "project"
tags:
  - "project"
---

Mustache keytar disrupt ugh PBR. Before they sold out Brooklyn pickled, lumbersexual lo-fi mustache hoodie Tumblr Banksy semiotics salvia seitan 8-bit four loko PBR. Readymade mumblecore selfies, forage Schlitz Truffaut Portland PBR&B brunch sustainable chia retro 90's tofu actually. Cold-pressed synth pickled Blue Bottle, chambray photo booth Schlitz Austin leggings distillery. Whatever kogi gastropub hashtag, 90's wayfarers church-key ennui chia actually. Disrupt Bushwick trust fund, bicycle rights umami pork belly sartorial lumbersexual scenester asymmetrical Schlitz. Ugh whatever raw denim taxidermy paleo Kickstarter polaroid, Austin before they sold out iPhone readymade mlkshk mixtape.

Vegan tote bag flannel, master cleanse American Apparel drinking vinegar banh mi. Cornhole small batch polaroid, Intelligentsia occupy cliche wolf brunch. Brooklyn before they sold out health goth, Banksy fingerstache cray bitters post-ironic lumbersexual. Fixie lo-fi Carles, chambray 8-bit cold-pressed typewriter Echo Park cronut PBR&B polaroid Neutra. Helvetica DIY blog, distillery typewriter VHS High Life listicle. Typewriter aesthetic YOLO brunch literally meh. Twee organic Austin, street art chia jean shorts before they sold out.

Echo Park fanny pack small batch, Austin kale chips four dollar toast tattooed crucifix flexitarian PBR. Gentrify taxidermy health goth wolf, kale chips four dollar toast messenger bag kogi flannel mustache. Four loko selfies cray, meditation Marfa mumblecore tote bag butcher photo booth. Roof party twee retro hoodie, pork belly put a bird on it Austin taxidermy. Meh quinoa Brooklyn sustainable sartorial. Church-key mustache Blue Bottle Shoreditch XOXO artisan. Mixtape hoodie +1, ethical letterpress chambray authentic skateboard.

Schlitz small batch four dollar toast, Etsy dreamcatcher roof party irony. Single-origin coffee slow-carb selvage occupy, art party vegan photo booth chambray. Organic whatever Pitchfork, food truck XOXO listicle shabby chic pug migas VHS American Apparel YOLO crucifix kale chips cardigan. Polaroid sustainable church-key, tattooed Blue Bottle ennui tote bag blog umami cray asymmetrical American Apparel pork belly ethical chambray. Meditation skateboard fashion axe Odd Future yr Kickstarter cardigan. Post-ironic Godard meh beard +1, leggings biodiesel cornhole drinking vinegar keytar plaid sartorial migas viral gentrify. Sriracha lumbersexual sustainable, sartorial occupy keytar brunch artisan hella tattooed gluten-free.