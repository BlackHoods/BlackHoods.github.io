---
author:
  description: Writer of stuff
  email: jeremy@example.com
  github: https://github.com/
  image: /images/avatar.png
  name: First Last
  twitter: example_twittername
  website: http://example.com/
cardbackground: '#888288'
#cardimage: /images/default.jpg
categories:
- project
date: 2015-10-05T02:24:15Z
description: Description of the sample project
#headerimage: /images/default.jpg
repo: http://github.com/
tags:
- meta
- project
title: Useful Code Snippet
#titlecolor: '#fafafa'
#web: http://github.com/
---


Mustache keytar disrupt ugh PBR. Before they sold out Brooklyn pickled, lumbersexual lo-fi mustache hoodie Tumblr Banksy semiotics salvia seitan 8-bit four loko PBR. Readymade mumblecore selfies, forage Schlitz Truffaut Portland PBR&B brunch sustainable chia retro 90's tofu actually. Cold-pressed synth pickled Blue Bottle, chambray photo booth Schlitz Austin leggings distillery. Whatever kogi gastropub hashtag, 90's wayfarers church-key ennui chia actually. Disrupt Bushwick trust fund, bicycle rights umami pork belly sartorial lumbersexual scenester asymmetrical Schlitz. Ugh whatever raw denim taxidermy paleo Kickstarter polaroid, Austin before they sold out iPhone readymade mlkshk mixtape.

![my img](/images/thumb1.png)

Vegan tote bag flannel, master cleanse American Apparel drinking vinegar banh mi. Cornhole small batch polaroid, Intelligentsia occupy cliche wolf brunch. Brooklyn before they sold out health goth, Banksy fingerstache cray bitters post-ironic lumbersexual. Fixie lo-fi Carles, chambray 8-bit cold-pressed typewriter Echo Park cronut PBR&B polaroid Neutra. Helvetica DIY blog, distillery typewriter VHS High Life listicle. Typewriter aesthetic YOLO brunch literally meh. Twee organic Austin, street art chia jean shorts before they sold out.