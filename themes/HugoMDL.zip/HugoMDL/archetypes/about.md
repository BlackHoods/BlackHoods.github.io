---
title: "About Me"
description: "All About Me"
date: "2015-08-18"
type: "about"
layout: "single"
categories:
    - "bio"
    - "about"
    - "meta"
tags:
    - "bio"
blurb: "Just a city boy, born and raised in South Detroit"
recentposts: 5
recentprojects: 5
photo: "/images/avatar.png"
cardheaderimage: "/images/default.jpg" #optional: default solid color if unset
cardbackground: "#263238" #optional: card background color; only shows when no image specified
---

#### Education
>2015    MA, Wine Appreciation, University of Caledonia
>2013    BA, Painting with Condiments, University of Caledonia

#### Publications
> Big 'ol book of condiment paintings (2015)
> Distincive Properties of Caledonia Wine. Journal of Wine Tasting. (2015)

#### Places I've worked
>I don't work :(